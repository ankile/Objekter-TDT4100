package interfaces;

import interfaces.Card;

public interface CardContainer {
	
	int getCardCount();
	Card getCard(int n);

	

	
}
